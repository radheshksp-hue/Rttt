# Privacy

*Applies to PDF Master 0.1.0. Written for the features that exist today; update it whenever features change.*

## Summary

PDF Master works on your device. **Your documents are not uploaded anywhere.**
This version contains no ads, no analytics, no crash reporting and no network code.

## What the app touches

| Data | Why | Where it lives | Leaves the device? |
|---|---|---|---|
| PDFs you pick | Show, merge, split, reorder, rotate | Read through the system file picker; temporary copies in the app's private cache while a tool runs | No |
| Result files | Hold a verified result until you save or discard it | App private cache (`cache/results`), removed when discarded or after 24 hours | Only if **you** press Share or Save |
| Recent files list | Quick access | App private storage (file name, size, URI, time opened) | No |
| Theme choice | Remember light/dark | App private storage | No |

## Permissions

None are declared. Files are reached only through Android's document picker, which gives the app access to
exactly the files you choose.

## Logging

Document contents, file names and passwords are not written to logs.

## Your control

* **Settings → Clear recent files** empties the list (your PDFs are not deleted).
* Uninstalling the app removes everything it stored.

## Future features

Ads (AdMob), cloud features or OCR language downloads would change this policy. They are not part of this
version, and this document must be updated and re-reviewed before any of them ship.

## Contact

*Add your own support e-mail or web address here before publishing. The app does not claim one.*
