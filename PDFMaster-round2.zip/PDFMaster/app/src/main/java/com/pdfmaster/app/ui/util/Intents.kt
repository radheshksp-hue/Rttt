package com.pdfmaster.app.ui.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.pdfmaster.app.print.PdfPrintAdapter
import java.io.File

object Intents {

    fun resultUri(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /** Shares one or more PDFs through the system share sheet. */
    fun sharePdfs(context: Context, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_STREAM, uris.first())
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
        }
        intent.type = "application/pdf"
        val clip = ClipData.newRawUri("PDF", uris.first())
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(Intent.createChooser(intent, "Share PDF"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No app available to share with.", Toast.LENGTH_SHORT).show()
        }
    }

    fun print(context: Context, uri: Uri, documentName: String) {
        val manager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (manager == null) {
            Toast.makeText(context, "Printing isn't available on this device.", Toast.LENGTH_SHORT).show()
            return
        }
        manager.print(documentName, PdfPrintAdapter(context.applicationContext, uri, documentName), null)
    }
}
