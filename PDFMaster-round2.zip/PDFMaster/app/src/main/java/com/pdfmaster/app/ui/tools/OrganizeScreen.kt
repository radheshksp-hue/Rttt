package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.OperationState
import com.pdfmaster.app.domain.PageItem
import com.pdfmaster.app.pdf.PageBitmapCache
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.ui.components.MessageCard
import com.pdfmaster.app.ui.components.PdfPageImage

private const val THUMBNAIL_WIDTH_PX = 240

@Composable
fun OrganizeScreen(
    container: AppContainer,
    uri: Uri,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
) {
    val viewModel: OrganizeViewModel = viewModel(
        key = "organize:$uri",
        factory = viewModelFactory { initializer { OrganizeViewModel(container, uri) } },
    )
    val load by viewModel.load.collectAsStateWithLifecycle()
    val editor by viewModel.editor.collectAsStateWithLifecycle()
    val processing by viewModel.processing.state.collectAsStateWithLifecycle()

    var confirmDelete by rememberSaveable { mutableStateOf(false) }
    var confirmLeave by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = editor.hasChanges) { confirmLeave = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Organize pages") },
                navigationIcon = {
                    IconButton(onClick = { if (editor.hasChanges) confirmLeave = true else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::undo, enabled = editor.canUndo) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = viewModel::redo, enabled = editor.canRedo) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo")
                    }
                },
            )
        },
    ) { padding ->
        when (val state = load) {
            OrganizeLoad.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            is OrganizeLoad.Error -> Box(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                MessageCard(message = state.message, isError = true)
            }

            is OrganizeLoad.Ready -> Column(Modifier.fillMaxSize().padding(padding)) {
                EditToolbar(
                    hasSelection = editor.selectedCount > 0,
                    canDelete = editor.selectedCount in 1 until editor.pages.size,
                    canReverse = editor.pages.size > 1,
                    onRotateLeft = { viewModel.rotate(-90) },
                    onRotateRight = { viewModel.rotate(90) },
                    onMoveEarlier = { viewModel.move(-1) },
                    onMoveLater = { viewModel.move(1) },
                    onDuplicate = viewModel::duplicateSelected,
                    onDelete = { confirmDelete = true },
                    onReverse = viewModel::reverse,
                    onSelectAll = viewModel::selectAll,
                    onClear = viewModel::clearSelection,
                    onSelectOdd = viewModel::selectOdd,
                    onSelectEven = viewModel::selectEven,
                )
                Text(
                    "${editor.pages.size} ${if (editor.pages.size == 1) "page" else "pages"} · ${editor.selectedCount} selected",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                PageGrid(
                    renderer = state.renderer,
                    cache = viewModel.cache,
                    pages = editor.pages,
                    selected = editor.selected,
                    onToggle = viewModel::toggle,
                    modifier = Modifier.weight(1f),
                )
                Column(
                    Modifier
                        .heightIn(max = 280.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                ) {
                    ToolOutput(viewModel = viewModel, onOpenPdf = onOpenPdf)
                }
                Surface(tonalElevation = 3.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        val busy = processing is OperationState.Running
                        Button(
                            onClick = viewModel::saveAll,
                            enabled = editor.hasChanges && !busy,
                            modifier = Modifier.weight(1f),
                        ) { Text("Create new PDF") }
                        OutlinedButton(
                            onClick = viewModel::saveSelected,
                            enabled = editor.selectedCount > 0 && !busy,
                            modifier = Modifier.weight(1f),
                        ) { Text("Selected only") }
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${editor.selectedCount} ${if (editor.selectedCount == 1) "page" else "pages"}?") },
            text = {
                Text(
                    "They're removed from the new copy only. Your original file isn't changed, " +
                        "and you can undo this.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    viewModel.deleteSelected()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep") } },
        )
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Discard your changes?") },
            text = { Text("The page changes you made haven't been saved to a new PDF.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    onBack()
                }) { Text("Discard") }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text("Keep editing") } },
        )
    }
}

@Composable
private fun EditToolbar(
    hasSelection: Boolean,
    canDelete: Boolean,
    canReverse: Boolean,
    onRotateLeft: () -> Unit,
    onRotateRight: () -> Unit,
    onMoveEarlier: () -> Unit,
    onMoveLater: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onReverse: () -> Unit,
    onSelectAll: () -> Unit,
    onClear: () -> Unit,
    onSelectOdd: () -> Unit,
    onSelectEven: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolChip("Rotate left", Icons.Filled.RotateLeft, hasSelection, onRotateLeft)
            ToolChip("Rotate right", Icons.Filled.RotateRight, hasSelection, onRotateRight)
            ToolChip("Move earlier", Icons.Filled.KeyboardArrowLeft, hasSelection, onMoveEarlier)
            ToolChip("Move later", Icons.Filled.KeyboardArrowRight, hasSelection, onMoveLater)
            ToolChip("Duplicate", Icons.Filled.ContentCopy, hasSelection, onDuplicate)
            ToolChip("Delete", Icons.Filled.Delete, canDelete, onDelete)
            ToolChip("Reverse order", Icons.Filled.SwapVert, canReverse, onReverse)
        }
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AssistChip(onClick = onSelectAll, label = { Text("Select all") })
            AssistChip(onClick = onClear, label = { Text("Clear selection") }, enabled = hasSelection)
            AssistChip(onClick = onSelectOdd, label = { Text("Odd pages") })
            AssistChip(onClick = onSelectEven, label = { Text("Even pages") })
        }
    }
}

@Composable
private fun ToolChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    AssistChip(
        onClick = onClick,
        enabled = enabled,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
    )
}

@Composable
private fun PageGrid(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    pages: List<PageItem>,
    selected: Set<Long>,
    onToggle: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        modifier = modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(pages, key = { _, page -> page.id }) { index, page ->
            val position = index + 1
            PageCell(
                renderer = renderer,
                cache = cache,
                page = page,
                position = position,
                selected = page.id in selected,
                onToggle = { onToggle(page.id) },
            )
        }
    }
}

@Composable
private fun PageCell(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    page: PageItem,
    position: Int,
    selected: Boolean,
    onToggle: () -> Unit,
) {
    val shape = RoundedCornerShape(8.dp)
    val description = buildString {
        append("Page $position, from original page ${page.sourceIndex + 1}")
        if (page.rotation != 0) append(", rotated ${page.rotation} degrees")
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .semantics(mergeDescendants = true) { contentDescription = description }
            .toggleable(value = selected, role = Role.Checkbox, onValueChange = { onToggle() }),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(shape)
                .border(
                    border = BorderStroke(
                        width = if (selected) 3.dp else 1.dp,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    ),
                    shape = shape,
                ),
        ) {
            BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val sideways = page.rotation == 90 || page.rotation == 270
                val sizeModifier = if (sideways) Modifier.requiredSize(maxHeight, maxWidth) else Modifier.fillMaxSize()
                PdfPageImage(
                    renderer = renderer,
                    cache = cache,
                    pageIndex = page.sourceIndex,
                    widthPx = THUMBNAIL_WIDTH_PX,
                    modifier = sizeModifier.graphicsLayer { rotationZ = page.rotation.toFloat() },
                )
            }
            if (selected) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(22.dp),
                )
            }
        }
        Text(
            text = if (page.rotation != 0) "$position · ${page.rotation}°" else "$position",
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
