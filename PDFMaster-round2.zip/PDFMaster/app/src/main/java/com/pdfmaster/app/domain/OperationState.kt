package com.pdfmaster.app.domain

/** Real progress reported by an operation: [done] of [total] steps, never an invented percentage. */
data class OperationProgress(
    val done: Int,
    val total: Int,
    val label: String,
) {
    val fraction: Float?
        get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else null
}

sealed interface OperationState<out T> {
    data object Idle : OperationState<Nothing>
    data class Running(val progress: OperationProgress? = null) : OperationState<Nothing>
    data class Completed<out T>(val result: T) : OperationState<T>
    data class Failed(val message: String) : OperationState<Nothing>
    data object Cancelled : OperationState<Nothing>
}
