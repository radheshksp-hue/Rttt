package com.pdfmaster.app.domain

enum class SplitMode { EXTRACT, RANGES, EACH_PAGE }

/** One output document: [pages] are 1-based and in output order. */
data class SplitGroup(
    val pages: List<Int>,
    val nameSuffix: String,
    val label: String,
)

sealed interface SplitPlanResult {
    data class Success(val groups: List<SplitGroup>) : SplitPlanResult
    data class Error(val message: String) : SplitPlanResult
}

/** Turns the user's choice into the exact list of output documents, before anything is processed. */
object SplitPlanner {

    fun plan(mode: SplitMode, input: String, pageCount: Int): SplitPlanResult = when (mode) {
        SplitMode.EXTRACT -> when (val parsed = PageRanges.parse(input, pageCount)) {
            is RangeParseResult.Error -> SplitPlanResult.Error(parsed.message)
            is RangeParseResult.Success -> SplitPlanResult.Success(
                listOf(
                    SplitGroup(
                        pages = PageRanges.expand(parsed.ranges),
                        nameSuffix = "extract",
                        label = "Pages " + parsed.ranges.joinToString(", ") { PageRanges.label(it) },
                    ),
                ),
            )
        }

        SplitMode.RANGES -> when (val parsed = PageRanges.parse(input, pageCount)) {
            is RangeParseResult.Error -> SplitPlanResult.Error(parsed.message)
            is RangeParseResult.Success -> SplitPlanResult.Success(
                parsed.ranges.map {
                    SplitGroup(
                        pages = it.toList(),
                        nameSuffix = "pages_${PageRanges.label(it)}",
                        label = "Pages ${PageRanges.label(it)}",
                    )
                },
            )
        }

        SplitMode.EACH_PAGE ->
            if (pageCount < 1) {
                SplitPlanResult.Error("The document has no pages.")
            } else {
                val width = pageCount.toString().length
                SplitPlanResult.Success(
                    (1..pageCount).map {
                        SplitGroup(
                            pages = listOf(it),
                            nameSuffix = "page_${it.toString().padStart(width, '0')}",
                            label = "Page $it",
                        )
                    },
                )
            }
    }
}
