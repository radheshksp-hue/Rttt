package com.pdfmaster.app.domain

import java.util.Locale

object SizeFormat {
    private val units = arrayOf("KB", "MB", "GB", "TB")

    fun format(bytes: Long): String {
        if (bytes < 0) return "Unknown size"
        if (bytes < 1024) return "$bytes B"
        var value = bytes.toDouble() / 1024
        var unit = 0
        while (value >= 1024 && unit < units.lastIndex) {
            value /= 1024
            unit++
        }
        val pattern = when {
            value >= 100 -> "%.0f %s"
            value >= 10 -> "%.1f %s"
            else -> "%.2f %s"
        }
        return String.format(Locale.ROOT, pattern, value, units[unit])
    }
}
