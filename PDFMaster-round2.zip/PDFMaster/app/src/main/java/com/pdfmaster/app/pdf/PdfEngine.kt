package com.pdfmaster.app.pdf

import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.FileNaming
import com.pdfmaster.app.domain.OperationProgress
import com.pdfmaster.app.domain.PageEntry
import com.pdfmaster.app.domain.normalizeRotation
import com.pdfmaster.app.storage.DocumentAccess
import com.pdfmaster.app.storage.DocumentInfo
import com.pdfmaster.app.storage.TempFiles
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Real PDF processing on top of PDFBox-Android.
 *
 * Every operation follows the same contract:
 *  1. copy inputs to private scratch space (originals are never touched),
 *  2. validate them (readable, not protected, has pages),
 *  3. build the output,
 *  4. reopen the output and check page count (and rotation),
 *  5. only then return it. On any failure or cancellation the partial output is deleted.
 */
class PdfEngine(
    private val access: DocumentAccess,
    private val temp: TempFiles,
) {

    /** Merges [sources] in order into one verified PDF. */
    suspend fun merge(
        sources: List<DocumentInfo>,
        report: (OperationProgress) -> Unit,
    ): ProducedFile = withContext(Dispatchers.IO) {
        if (sources.size < 2) {
            throw AppException(AppException.Kind.INVALID_INPUT, "Select at least two PDFs to merge.")
        }
        val job = coroutineContext[Job]
        val check: () -> Unit = { job?.ensureActive() }

        val workDir = temp.newWorkDir()
        val resultDir = temp.newResultDir()
        var success = false
        try {
            val totalBytes = sources.sumOf { it.sizeBytes.coerceAtLeast(0L) }
            access.ensureFreeSpace(workDir, totalBytes * 3)

            val steps = sources.size + 2
            var expectedPages = 0
            val locals = sources.mapIndexed { index, source ->
                check()
                report(OperationProgress(index, steps, "Reading ${source.displayName}"))
                val local = File(workDir, "input_$index.pdf")
                access.copyToFile(source.uri, local, check)
                expectedPages += openValidated(local, source.displayName).use { it.numberOfPages }
                local
            }

            check()
            report(OperationProgress(sources.size, steps, "Merging pages"))
            val output = File(resultDir, "merged.pdf")
            val merger = PDFMergerUtility()
            locals.forEach { merger.addSource(it) }
            merger.destinationFileName = output.absolutePath
            try {
                merger.mergeDocuments(scratch())
            } catch (e: IOException) {
                throw AppException(
                    AppException.Kind.INVALID_PDF,
                    "The pages couldn't be combined. One of the files may be damaged.",
                    e,
                )
            }

            check()
            report(OperationProgress(sources.size + 1, steps, "Checking the result"))
            verifyOutput(output, expectedPages, null)

            success = true
            ProducedFile(output, output.name, expectedPages)
        } finally {
            workDir.deleteRecursively()
            if (!success) resultDir.deleteRecursively()
        }
    }

    /**
     * Builds one output document per [PagePlan] from a single [source].
     * This one function powers extract, split-by-range, split-every-page and the page organizer.
     */
    suspend fun buildDocuments(
        source: DocumentInfo,
        plans: List<PagePlan>,
        report: (OperationProgress) -> Unit,
    ): List<ProducedFile> = withContext(Dispatchers.IO) {
        if (plans.isEmpty() || plans.any { it.entries.isEmpty() }) {
            throw AppException(AppException.Kind.INVALID_INPUT, "There are no pages to save.")
        }
        val job = coroutineContext[Job]
        val check: () -> Unit = { job?.ensureActive() }

        val workDir = temp.newWorkDir()
        val resultDir = temp.newResultDir()
        var success = false
        try {
            access.ensureFreeSpace(workDir, source.sizeBytes.coerceAtLeast(0L) * 3)
            val steps = plans.size + 1
            report(OperationProgress(0, steps, "Reading ${source.displayName}"))
            val local = File(workDir, "source.pdf")
            access.copyToFile(source.uri, local, check)

            val produced = ArrayList<ProducedFile>(plans.size)
            val usedNames = mutableSetOf<String>()

            openValidated(local, source.displayName).use { sourceDoc ->
                val pageCount = sourceDoc.numberOfPages
                val sourceRotations = (0 until pageCount).map { normalizeRotation(sourceDoc.getPage(it).rotation) }

                plans.forEachIndexed { index, plan ->
                    check()
                    report(OperationProgress(index + 1, steps, "Creating ${plan.fileName}"))
                    requireValidEntries(plan.entries, pageCount)

                    val fileName = FileNaming.uniqueName(plan.fileName, usedNames)
                    usedNames += fileName
                    val output = File(resultDir, fileName)
                    val expectedRotations = plan.entries.map {
                        normalizeRotation(sourceRotations[it.sourceIndex] + it.rotationDelta)
                    }

                    PDDocument(scratch()).use { target ->
                        plan.entries.forEachIndexed { position, entry ->
                            val imported = target.importPage(sourceDoc.getPage(entry.sourceIndex))
                            imported.rotation = expectedRotations[position]
                            sanitizeAnnotations(imported)
                        }
                        try {
                            target.save(output)
                        } catch (e: IOException) {
                            throw AppException(
                                AppException.Kind.DESTINATION_FAILED,
                                "The new PDF couldn't be written. The device may be low on storage.",
                                e,
                            )
                        }
                    }

                    verifyOutput(output, plan.entries.size, expectedRotations)
                    produced += ProducedFile(output, fileName, plan.entries.size)
                }
            }

            success = true
            produced
        } finally {
            workDir.deleteRecursively()
            if (!success) resultDir.deleteRecursively()
        }
    }

    // ---- helpers ----

    private fun scratch(): MemoryUsageSetting =
        MemoryUsageSetting.setupTempFileOnly().setTempDir(temp.scratchDir())

    /** Opens [file] and rejects protected, unreadable or empty documents with a clear message. */
    private fun openValidated(file: File, name: String): PDDocument {
        val document = try {
            PDDocument.load(file, scratch())
        } catch (e: InvalidPasswordException) {
            throw protectedPdf(name, e)
        } catch (e: IOException) {
            throw AppException(
                AppException.Kind.INVALID_PDF,
                "\"$name\" couldn't be read as a PDF. The file may be damaged or not a PDF.",
                e,
            )
        } catch (e: RuntimeException) {
            throw AppException(
                AppException.Kind.INVALID_PDF,
                "\"$name\" couldn't be read as a PDF. The file may be damaged or not a PDF.",
                e,
            )
        }
        try {
            if (document.isEncrypted) throw protectedPdf(name, null)
            if (document.numberOfPages == 0) {
                throw AppException(AppException.Kind.INVALID_PDF, "\"$name\" has no pages.")
            }
        } catch (t: Throwable) {
            try {
                document.close()
            } catch (ignored: IOException) {
            }
            throw t
        }
        return document
    }

    private fun protectedPdf(name: String, cause: Throwable?) = AppException(
        AppException.Kind.ENCRYPTED,
        "\"$name\" is password-protected. Working with protected PDFs isn't available in this version.",
        cause,
    )

    private fun requireValidEntries(entries: List<PageEntry>, pageCount: Int) {
        val bad = entries.firstOrNull { it.sourceIndex < 0 || it.sourceIndex >= pageCount }
        if (bad != null) {
            throw AppException(
                AppException.Kind.INVALID_INPUT,
                "Page ${bad.sourceIndex + 1} doesn't exist in this document ($pageCount pages).",
            )
        }
    }

    /** Re-opens the written file and compares it with what was expected. */
    private fun verifyOutput(file: File, expectedPages: Int, expectedRotations: List<Int>?) {
        if (!file.isFile || file.length() == 0L) {
            throw AppException(
                AppException.Kind.VERIFICATION_FAILED,
                "The result file wasn't created correctly, so nothing was saved. Please try again.",
            )
        }
        val document = try {
            PDDocument.load(file, scratch())
        } catch (e: Exception) {
            throw AppException(
                AppException.Kind.VERIFICATION_FAILED,
                "The result couldn't be reopened to check it, so it was discarded. Please try again.",
                e,
            )
        }
        document.use { doc ->
            val actualPages = doc.numberOfPages
            if (actualPages != expectedPages) {
                throw AppException(
                    AppException.Kind.VERIFICATION_FAILED,
                    "The result has $actualPages pages instead of $expectedPages, so it was discarded.",
                )
            }
            expectedRotations?.forEachIndexed { index, expected ->
                if (normalizeRotation(doc.getPage(index).rotation) != expected) {
                    throw AppException(
                        AppException.Kind.VERIFICATION_FAILED,
                        "A page rotation in the result is wrong, so it was discarded. Please try again.",
                    )
                }
            }
        }
    }

    /**
     * Imported pages must not drag the whole source document along through annotation links.
     * Links, form widgets and popups are therefore dropped; visible markup annotations are kept.
     */
    private fun sanitizeAnnotations(page: PDPage) {
        try {
            val all = page.annotations
            if (all.isEmpty()) return
            val kept = all.filter { KEPT_ANNOTATIONS.contains(it.subtype ?: "") }
            kept.forEach {
                it.cosObject.removeItem(COSName.P)
                it.cosObject.removeItem(COSName.POPUP)
            }
            page.annotations = kept
        } catch (e: Exception) {
            page.cosObject.removeItem(COSName.ANNOTS)
        }
    }

    private companion object {
        val KEPT_ANNOTATIONS = setOf(
            "Text", "FreeText", "Highlight", "Underline", "StrikeOut", "Squiggly",
            "Line", "Square", "Circle", "Polygon", "PolyLine", "Ink", "Stamp",
        )
    }
}
