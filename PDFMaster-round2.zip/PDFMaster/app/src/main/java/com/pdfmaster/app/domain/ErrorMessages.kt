package com.pdfmaster.app.domain

import java.io.FileNotFoundException
import java.io.IOException

/** Turns any throwable into a short, actionable sentence. Never includes file contents. */
object ErrorMessages {
    fun describe(error: Throwable): String = when (error) {
        is AppException -> error.message ?: "The operation failed."
        is OutOfMemoryError ->
            "The device ran out of memory while working on this file. Try a smaller file or close other apps."
        is SecurityException ->
            "Access to the file was denied. Pick the file again to grant access."
        is FileNotFoundException ->
            "The file could not be found. It may have been moved or deleted."
        is IOException ->
            "A file error occurred while reading or writing data. Please try again."
        else -> "Something went wrong. Please try again."
    }
}
