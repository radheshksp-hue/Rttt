package com.pdfmaster.app

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class PdfMasterApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
        container = AppContainer(this)
        // Leftovers from a crash or a killed process; done off the main thread.
        Thread { container.temp.cleanStale() }.start()
    }
}
