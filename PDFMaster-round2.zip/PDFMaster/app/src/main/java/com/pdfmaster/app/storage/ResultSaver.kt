package com.pdfmaster.app.storage

import android.net.Uri
import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.ErrorMessages
import com.pdfmaster.app.domain.FileNaming
import com.pdfmaster.app.domain.OperationProgress
import com.pdfmaster.app.pdf.ProducedFile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

data class SavedFile(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val location: String,
)

/** Copies verified results from the cache to the place the user chose, then verifies the copy. */
class ResultSaver(private val access: DocumentAccess) {

    suspend fun saveSingle(file: File, destination: Uri): SavedFile = withContext(Dispatchers.IO) {
        val job = coroutineContext[Job]
        try {
            val written = access.copyFileToUri(file, destination) { job?.ensureActive() }
            val name = try {
                access.describe(destination).displayName
            } catch (e: AppException) {
                file.name
            }
            SavedFile(destination, name, written, access.friendlyLocation(destination))
        } catch (t: Throwable) {
            access.deleteQuietly(destination)
            throw t
        }
    }

    suspend fun saveMany(
        files: List<ProducedFile>,
        treeUri: Uri,
        report: (OperationProgress) -> Unit,
    ): List<SavedFile> = withContext(Dispatchers.IO) {
        val job = coroutineContext[Job]
        val existing = access.listChildNames(treeUri).toMutableSet()
        val saved = ArrayList<SavedFile>()
        try {
            files.forEachIndexed { index, produced ->
                job?.ensureActive()
                report(OperationProgress(index, files.size, "Saving ${produced.displayName}"))
                val name = FileNaming.uniqueName(produced.displayName, existing)
                existing += name
                val uri = access.createInTree(treeUri, name, "application/pdf")
                try {
                    val written = access.copyFileToUri(produced.file, uri) { job?.ensureActive() }
                    saved += SavedFile(uri, name, written, access.friendlyLocation(uri))
                } catch (t: Throwable) {
                    access.deleteQuietly(uri)
                    throw t
                }
            }
            saved
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            if (saved.isEmpty()) throw t
            throw AppException(
                AppException.Kind.DESTINATION_FAILED,
                "Saved ${saved.size} of ${files.size} files before an error: ${ErrorMessages.describe(t)}",
                t,
            )
        }
    }
}
