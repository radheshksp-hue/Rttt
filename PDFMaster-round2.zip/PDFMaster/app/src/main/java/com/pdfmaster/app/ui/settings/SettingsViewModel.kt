package com.pdfmaster.app.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.RecentFile
import com.pdfmaster.app.settings.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> = container.settings.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ThemeMode.SYSTEM)

    val recents: StateFlow<List<RecentFile>> = container.recents.recents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { container.settings.setThemeMode(mode) }
    }

    fun clearRecents() {
        viewModelScope.launch {
            recents.value.forEach { container.access.releaseRead(Uri.parse(it.uri)) }
            container.recents.clear()
        }
    }
}
