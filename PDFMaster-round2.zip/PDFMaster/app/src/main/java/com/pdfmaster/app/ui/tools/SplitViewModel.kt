package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.ErrorMessages
import com.pdfmaster.app.domain.FileNaming
import com.pdfmaster.app.domain.PageEntry
import com.pdfmaster.app.domain.SplitMode
import com.pdfmaster.app.domain.SplitPlanResult
import com.pdfmaster.app.domain.SplitPlanner
import com.pdfmaster.app.pdf.PagePlan
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.storage.DocumentInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SplitLoad {
    data object Loading : SplitLoad
    data class Ready(val info: DocumentInfo, val pageCount: Int) : SplitLoad
    data class Error(val message: String) : SplitLoad
}

class SplitViewModel(container: AppContainer, private val uri: Uri) : ToolViewModel(container) {

    private val _load = MutableStateFlow<SplitLoad>(SplitLoad.Loading)
    val load: StateFlow<SplitLoad> = _load.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                val info = container.access.describe(uri)
                val pages = PdfDocumentRenderer.open(
                    container.appContext,
                    container.access,
                    container.temp,
                    uri,
                    withPageSizes = false,
                ).use { it.pageCount }
                _load.value = SplitLoad.Ready(info, pages)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _load.value = SplitLoad.Error(ErrorMessages.describe(e))
            }
        }
    }

    /** Re-validates the request and starts building the output documents. */
    fun start(mode: SplitMode, rangeText: String) {
        val ready = _load.value as? SplitLoad.Ready ?: return
        val plan = SplitPlanner.plan(mode, rangeText, ready.pageCount) as? SplitPlanResult.Success ?: return
        val plans = plan.groups.map { group ->
            PagePlan(
                fileName = FileNaming.outputName(ready.info.displayName, group.nameSuffix),
                entries = group.pages.map { PageEntry(sourceIndex = it - 1, rotationDelta = 0) },
            )
        }
        startProcessing { report -> container.engine.buildDocuments(ready.info, plans, report) }
    }
}
