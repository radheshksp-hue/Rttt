package com.pdfmaster.app.domain

import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Locale

data class RecentFile(
    val uri: String,
    val name: String,
    /** -1 when the provider did not report a size. */
    val sizeBytes: Long,
    val openedAtMillis: Long,
)

enum class RecentSort(val label: String) {
    DATE("Date opened"),
    NAME("Name"),
    SIZE("Size"),
}

/** Plain-text storage format: one file per line, tab-separated, URL-encoded text fields. */
object RecentFilesCodec {

    fun encode(files: List<RecentFile>): String = files.joinToString("\n") { file ->
        listOf(
            URLEncoder.encode(file.uri, "UTF-8"),
            URLEncoder.encode(file.name, "UTF-8"),
            file.sizeBytes.toString(),
            file.openedAtMillis.toString(),
        ).joinToString("\t")
    }

    /** Lines that cannot be parsed are skipped; a damaged store never crashes the app. */
    fun decode(raw: String?): List<RecentFile> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.lineSequence().mapNotNull { parseLine(it) }.toList()
    }

    private fun parseLine(line: String): RecentFile? {
        val fields = line.split('\t')
        if (fields.size != 4) return null
        return try {
            val uri = URLDecoder.decode(fields[0], "UTF-8")
            if (uri.isEmpty()) return null
            RecentFile(
                uri = uri,
                name = URLDecoder.decode(fields[1], "UTF-8"),
                sizeBytes = fields[2].toLong(),
                openedAtMillis = fields[3].toLong(),
            )
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}

object RecentFilesLogic {
    const val MAX_ENTRIES = 30

    /** Puts [file] first and removes any older entry for the same URI. */
    fun upsert(existing: List<RecentFile>, file: RecentFile, max: Int = MAX_ENTRIES): List<RecentFile> =
        (listOf(file) + existing.filterNot { it.uri == file.uri }).take(max)

    fun remove(existing: List<RecentFile>, uri: String): List<RecentFile> =
        existing.filterNot { it.uri == uri }

    fun filterAndSort(files: List<RecentFile>, query: String, sort: RecentSort): List<RecentFile> {
        val trimmed = query.trim()
        val filtered =
            if (trimmed.isEmpty()) files else files.filter { it.name.contains(trimmed, ignoreCase = true) }
        return when (sort) {
            RecentSort.DATE -> filtered.sortedByDescending { it.openedAtMillis }
            RecentSort.NAME -> filtered.sortedBy { it.name.lowercase(Locale.ROOT) }
            RecentSort.SIZE -> filtered.sortedByDescending { it.sizeBytes }
        }
    }
}
