package com.pdfmaster.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.RenderSizing
import com.pdfmaster.app.storage.DocumentAccess
import com.pdfmaster.app.storage.TempFiles
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.IOException

/**
 * Renders pages with Android's built-in [PdfRenderer] (no extra library, no extra licence).
 *
 * PdfRenderer is not thread-safe and allows one open page at a time, so all access is
 * serialized with a mutex. Pages are rendered one at a time into bounded bitmaps.
 */
class PdfDocumentRenderer private constructor(
    private val descriptor: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    private val tempFile: File?,
    val pageCount: Int,
    /** Page sizes in points. Empty when the document was opened with `withPageSizes = false`. */
    val pageSizes: List<PageSize>,
) : Closeable {

    data class PageSize(val width: Int, val height: Int) {
        val aspect: Float get() = width.toFloat() / height.coerceAtLeast(1)
    }

    private val lock = Mutex()

    @Volatile
    private var closed = false

    @Volatile
    private var released = false

    suspend fun render(pageIndex: Int, widthPx: Int): Bitmap = withContext(Dispatchers.IO) {
        lock.withLock {
            if (closed) throw CancellationException("The document was closed")
            try {
                require(pageIndex in 0 until pageCount) { "Page $pageIndex is out of range" }
                val page = renderer.openPage(pageIndex)
                try {
                    val (width, height) = RenderSizing.fit(page.width, page.height, widthPx)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap
                } finally {
                    page.close()
                }
            } finally {
                if (closed) release()
            }
        }
    }

    override fun close() {
        closed = true
        // If a render is in progress it releases everything when it finishes.
        if (lock.tryLock()) {
            try {
                release()
            } finally {
                lock.unlock()
            }
        }
    }

    private fun release() {
        if (released) return
        released = true
        try {
            renderer.close()
        } catch (e: RuntimeException) {
            // Already closed or a page was still open; nothing more can be done.
        }
        try {
            descriptor.close()
        } catch (e: IOException) {
            // Ignore: the descriptor is being discarded anyway.
        }
        tempFile?.parentFile?.deleteRecursively()
    }

    private class NotSeekable : Exception()

    companion object {
        /**
         * Opens [uri]. Protected documents and damaged files produce an [AppException] with a
         * readable message. Providers that hand out non-seekable streams are copied to the cache.
         */
        suspend fun open(
            context: Context,
            access: DocumentAccess,
            temp: TempFiles,
            uri: Uri,
            withPageSizes: Boolean = true,
        ): PdfDocumentRenderer = withContext(Dispatchers.IO) {
            val info = access.describe(uri)
            val opened = try {
                tryOpen(access.openForRead(uri), null, info.displayName, withPageSizes)
            } catch (e: NotSeekable) {
                openFromCopy(access, temp, uri, info.displayName, withPageSizes)
            }
            val job = coroutineContext[Job]
            if (job != null && !job.isActive) {
                opened.close()
                throw CancellationException("Cancelled while opening")
            }
            opened
        }

        private fun openFromCopy(
            access: DocumentAccess,
            temp: TempFiles,
            uri: Uri,
            name: String,
            withPageSizes: Boolean,
        ): PdfDocumentRenderer {
            val dir = temp.newWorkDir()
            try {
                val file = File(dir, "document.pdf")
                access.copyToFile(uri, file)
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    return tryOpen(descriptor, file, name, withPageSizes)
                } catch (e: NotSeekable) {
                    throw AppException(
                        AppException.Kind.INVALID_PDF,
                        "\"$name\" couldn't be opened as a PDF.",
                        e,
                    )
                }
            } catch (t: Throwable) {
                dir.deleteRecursively()
                throw t
            }
        }

        private fun tryOpen(
            descriptor: ParcelFileDescriptor,
            tempFile: File?,
            name: String,
            withPageSizes: Boolean,
        ): PdfDocumentRenderer {
            try {
                val renderer = PdfRenderer(descriptor)
                try {
                    val count = renderer.pageCount
                    if (count == 0) {
                        throw AppException(AppException.Kind.INVALID_PDF, "\"$name\" has no pages.")
                    }
                    val sizes = if (withPageSizes) {
                        (0 until count).map { index ->
                            val page = renderer.openPage(index)
                            try {
                                PageSize(page.width, page.height)
                            } finally {
                                page.close()
                            }
                        }
                    } else {
                        emptyList()
                    }
                    return PdfDocumentRenderer(descriptor, renderer, tempFile, count, sizes)
                } catch (t: Throwable) {
                    renderer.close()
                    throw t
                }
            } catch (e: SecurityException) {
                closeQuietly(descriptor)
                throw AppException(
                    AppException.Kind.ENCRYPTED,
                    "\"$name\" is password-protected. Working with protected PDFs isn't available in this version.",
                    e,
                )
            } catch (e: IllegalArgumentException) {
                closeQuietly(descriptor)
                throw NotSeekable()
            } catch (e: IOException) {
                closeQuietly(descriptor)
                throw AppException(
                    AppException.Kind.INVALID_PDF,
                    "\"$name\" couldn't be read as a PDF. The file may be damaged or not a PDF.",
                    e,
                )
            } catch (e: AppException) {
                closeQuietly(descriptor)
                throw e
            }
        }

        private fun closeQuietly(descriptor: ParcelFileDescriptor) {
            try {
                descriptor.close()
            } catch (e: IOException) {
                // Ignore.
            }
        }
    }
}
