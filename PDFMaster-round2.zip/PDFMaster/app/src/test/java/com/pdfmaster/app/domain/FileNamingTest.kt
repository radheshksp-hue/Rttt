package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FileNamingTest {

    @Test
    fun sanitizeReplacesIllegalCharacters() {
        assertEquals("a_b_c_d", FileNaming.sanitize("a/b:c*d"))
    }

    @Test
    fun sanitizeNeverReturnsEmpty() {
        assertEquals("document", FileNaming.sanitize(""))
        assertEquals("document", FileNaming.sanitize("..."))
        assertEquals("document", FileNaming.sanitize("   "))
    }

    @Test
    fun stemStripsPdfExtensionCaseInsensitively() {
        assertEquals("report", FileNaming.stem("report.pdf"))
        assertEquals("report", FileNaming.stem("report.PDF"))
        assertEquals("report.v2", FileNaming.stem("report.v2.pdf"))
    }

    @Test
    fun stemKeepsNamesWithoutPdfExtension() {
        assertEquals("notes", FileNaming.stem("notes"))
    }

    @Test
    fun stemIsLengthLimited() {
        assertTrue(FileNaming.stem("x".repeat(500) + ".pdf").length <= 100)
    }

    @Test
    fun outputNameCombinesStemAndSuffix() {
        assertEquals("report_pages_1-3.pdf", FileNaming.outputName("report.pdf", "pages_1-3"))
    }

    @Test
    fun uniqueNameReturnsDesiredWhenFree() {
        assertEquals("a.pdf", FileNaming.uniqueName("a.pdf", listOf("b.pdf")))
    }

    @Test
    fun uniqueNameAddsCounterOnCollision() {
        assertEquals("a (1).pdf", FileNaming.uniqueName("a.pdf", listOf("a.pdf")))
    }

    @Test
    fun uniqueNameSkipsTakenCounters() {
        assertEquals("a (3).pdf", FileNaming.uniqueName("a.pdf", listOf("a.pdf", "a (1).pdf", "a (2).pdf")))
    }

    @Test
    fun uniqueNameIgnoresCase() {
        assertEquals("A (1).pdf", FileNaming.uniqueName("A.pdf", listOf("a.PDF")))
    }

    @Test
    fun uniqueNameHandlesNamesWithoutExtension() {
        assertEquals("notes (1)", FileNaming.uniqueName("notes", listOf("notes")))
    }
}
