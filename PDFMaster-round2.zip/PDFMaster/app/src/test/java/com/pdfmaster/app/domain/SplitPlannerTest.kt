package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SplitPlannerTest {

    private fun success(mode: SplitMode, input: String, pages: Int): List<SplitGroup> {
        val result = SplitPlanner.plan(mode, input, pages)
        assertTrue("Expected success but got $result", result is SplitPlanResult.Success)
        return (result as SplitPlanResult.Success).groups
    }

    @Test
    fun extractMakesOneGroupInTypedOrder() {
        val groups = success(SplitMode.EXTRACT, "3-4, 1", 5)
        assertEquals(1, groups.size)
        assertEquals(listOf(3, 4, 1), groups.single().pages)
    }

    @Test
    fun rangesMakeOneGroupPerRange() {
        val groups = success(SplitMode.RANGES, "1-2, 4, 6-", 7)
        assertEquals(listOf(listOf(1, 2), listOf(4), listOf(6, 7)), groups.map { it.pages })
        assertEquals(listOf("pages_1-2", "pages_4", "pages_6-7"), groups.map { it.nameSuffix })
    }

    @Test
    fun eachPageMakesOneGroupPerPageWithPaddedNames() {
        val groups = success(SplitMode.EACH_PAGE, "", 12)
        assertEquals(12, groups.size)
        assertEquals("page_01", groups.first().nameSuffix)
        assertEquals("page_12", groups.last().nameSuffix)
    }

    @Test
    fun eachPageIgnoresTheRangeText() {
        assertEquals(3, success(SplitMode.EACH_PAGE, "nonsense", 3).size)
    }

    @Test
    fun invalidRangesBecomeErrors() {
        assertTrue(SplitPlanner.plan(SplitMode.EXTRACT, "9", 3) is SplitPlanResult.Error)
        assertTrue(SplitPlanner.plan(SplitMode.RANGES, "", 3) is SplitPlanResult.Error)
    }

    @Test
    fun documentsWithoutPagesAreRejected() {
        assertTrue(SplitPlanner.plan(SplitMode.EACH_PAGE, "", 0) is SplitPlanResult.Error)
    }
}
