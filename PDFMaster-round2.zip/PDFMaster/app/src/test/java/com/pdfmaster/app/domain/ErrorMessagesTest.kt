package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.FileNotFoundException
import java.io.IOException

class ErrorMessagesTest {

    @Test
    fun appExceptionsKeepTheirOwnMessage() {
        val error = AppException(AppException.Kind.INVALID_INPUT, "Pick at least two files.")
        assertEquals("Pick at least two files.", ErrorMessages.describe(error))
    }

    @Test
    fun technicalExceptionsNeverLeakTheirDetails() {
        val secret = "/storage/emulated/0/Private/passport-scan.pdf"
        listOf(
            IOException(secret),
            FileNotFoundException(secret),
            SecurityException(secret),
            IllegalStateException(secret),
            RuntimeException(secret),
        ).forEach { assertFalse(ErrorMessages.describe(it).contains(secret)) }
    }

    @Test
    fun outOfMemoryHasAHelpfulMessage() {
        assertTrue(ErrorMessages.describe(OutOfMemoryError()).contains("memory"))
    }
}
