package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class SizeFormatTest {

    @Test
    fun formatsBytes() {
        assertEquals("0 B", SizeFormat.format(0))
        assertEquals("1023 B", SizeFormat.format(1023))
    }

    @Test
    fun formatsKilobytesWithAdaptivePrecision() {
        assertEquals("1.00 KB", SizeFormat.format(1024))
        assertEquals("1.50 KB", SizeFormat.format(1536))
        assertEquals("10.0 KB", SizeFormat.format(10L * 1024))
        assertEquals("200 KB", SizeFormat.format(200L * 1024))
    }

    @Test
    fun formatsMegabytesAndGigabytes() {
        assertEquals("5.00 MB", SizeFormat.format(5L * 1024 * 1024))
        assertEquals("2.00 GB", SizeFormat.format(2L * 1024 * 1024 * 1024))
    }

    @Test
    fun negativeMeansUnknown() {
        assertEquals("Unknown size", SizeFormat.format(-1))
    }
}
