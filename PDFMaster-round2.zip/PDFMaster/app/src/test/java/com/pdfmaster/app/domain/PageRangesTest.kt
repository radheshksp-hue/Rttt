package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PageRangesTest {

    private fun ok(input: String, pages: Int): List<IntRange> {
        val result = PageRanges.parse(input, pages)
        assertTrue("Expected success for \"$input\" but got $result", result is RangeParseResult.Success)
        return (result as RangeParseResult.Success).ranges
    }

    private fun assertError(input: String, pages: Int) {
        val result = PageRanges.parse(input, pages)
        assertTrue("Expected error for \"$input\" but got $result", result is RangeParseResult.Error)
    }

    @Test
    fun parsesSinglePagesAndRanges() {
        assertEquals(listOf(1..3, 5..5, 7..9), ok("1-3, 5, 7-9", 10))
    }

    @Test
    fun ignoresWhitespaceAnywhere() {
        assertEquals(listOf(2..4), ok("  2 - 4  ", 10))
    }

    @Test
    fun openEndedRangeRunsToLastPage() {
        assertEquals(listOf(8..10), ok("8-", 10))
    }

    @Test
    fun openStartRangeBeginsAtFirstPage() {
        assertEquals(listOf(1..4), ok("-4", 10))
    }

    @Test
    fun keepsTypedOrderAndAllowsRepeats() {
        assertEquals(listOf(5..5, 1..2, 5..5), ok("5,1-2,5", 6))
    }

    @Test
    fun rejectsEmptyInput() {
        assertError("", 5)
        assertError("   ", 5)
    }

    @Test
    fun rejectsPageZeroAndOutOfRange() {
        assertError("0", 5)
        assertError("6", 5)
        assertError("1-6", 5)
    }

    @Test
    fun rejectsBackwardsRange() {
        assertError("4-2", 5)
    }

    @Test
    fun rejectsGarbage() {
        assertError("abc", 5)
        assertError("1-2-3", 5)
        assertError("-", 5)
        assertError("1,,2", 5)
        assertError("1.5", 5)
        assertError("-3-", 5)
    }

    @Test
    fun rejectsDocumentsWithNoPages() {
        assertError("1", 0)
    }

    @Test
    fun rejectsAbsurdlyLongNumbers() {
        assertError("99999999999999999999", 5)
    }

    @Test
    fun expandFlattensInOrder() {
        assertEquals(listOf(3, 4, 5, 1, 9), PageRanges.expand(listOf(3..5, 1..1, 9..9)))
    }

    @Test
    fun labelsSinglePagesAndRanges() {
        assertEquals("4", PageRanges.label(4..4))
        assertEquals("2-7", PageRanges.label(2..7))
    }
}
